/**
 * 
 */
function memVal(){
	
}