package com.BookMangement.Controller;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.BookMangement.Entity.Books;
import com.BookMangement.Entity.Member;
import com.BookMangement.Sevice.BookSer;

import jakarta.servlet.http.HttpServletRequest;



@Controller
public class BookController {
    @Autowired
	private BookSer bookser;
	
    
    //Add new book ...
	@RequestMapping("/addBook")
	@ResponseBody
	public String addBook(HttpServletRequest req) {
		int bookid=Integer.parseInt(req.getParameter("bookid"));
		int iabn=Integer.parseInt(req.getParameter("iabn"));
		String title=req.getParameter("title");
		String author=req.getParameter("author");
		String publisher=req.getParameter("publisher");
		String genre=req.getParameter("genre");
		String desciption=req.getParameter("desciption");
		int pages= Integer.parseInt(req.getParameter("pages"));
		int price=Integer.parseInt(req.getParameter("price"));
		String language=req.getParameter("language");
		List<Books>lb=bookser.searchBookById(bookid);
		if(lb.isEmpty()) {
			bookser.addBook(bookid, iabn, title, author, publisher,
					new Date(), genre, desciption, pages, price, language);
			return "Book Added...";
		}
		else 
			return "Bookid already exist"+bookid;
		
	}
	//Update price by using id...
	@RequestMapping("/upBook")
	@ResponseBody
	public String upBookById(HttpServletRequest req) {
		int bookid=Integer.parseInt(req.getParameter("bookid"));
		int price=Integer.parseInt(req.getParameter("price"));
		List<Books>lb=bookser.searchBookById(bookid);
		if(lb.isEmpty()) {
			return "Book not found.."+bookid;
		}
		else {
			bookser.upBookById(bookid,price);
			return "BookId "+bookid+" price updated...to"+price;
		}
		
	}
	
	//delete by Book Id..
	@RequestMapping("/delBook")
	@ResponseBody
	public String delBookById(Books book,HttpServletRequest req,Model m) {
	int bookid=Integer.parseInt(req.getParameter("bookid"));
	List<Books>lb=bookser.searchBookById(bookid);
	if(lb.isEmpty()) {
		
		return "Book Not Found";
	}
	  bookser.delByID(bookid);
		return "Book Deleted "+bookid;
	}
	
	//Search Book by Id...
	@RequestMapping("/SearchBookbyId")
//	@ResponseBody
	public String searchBookById(Books book,HttpServletRequest req,Model m) {
		int bookid=Integer.parseInt(req.getParameter("bookid"));
		List<Books>lb=bookser.searchBookById(bookid);
		if(lb.isEmpty()) {
			return "notFound";
		}
		else {
	    m.addAttribute("lm", lb);
		m.addAllAttributes(lb);
		return "listBook";
		}
	}
	//List of Book 
	@RequestMapping("/lbook")
	public String getAllBook(Model m) {
	
		List<Books>lm= bookser.getAllBook();
		m.addAttribute("lb",lm);
		m.addAllAttributes(lm);
		if(lm.isEmpty()) {
			return "notFound";
		}
		return "listBook";
	}
	
	
    //Wel page anchor tags----------------------------------------------------------//
	
	@RequestMapping("/addB")
	public String addB() {
		return "addBook";
	}
	@RequestMapping("/upB")
	public String upB() {
		return "upBook";
	}
	@RequestMapping("/Searbook")
	public String Searbook() {
		return "/SearchBookById";
	}
	@RequestMapping("/delB")
	public String delBook() {
		return "/delBookById";
	}
	//----------------------------------------------------------//
		
}
