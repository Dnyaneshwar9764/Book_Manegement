package com.BookMangement.Controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import com.BookMangement.Entity.Member;
import com.BookMangement.Sevice.MemberSer;

import jakarta.servlet.http.HttpServletRequest;


@Controller
public class MemberCotroller {
	@Autowired
	private MemberSer memberser;
	
	@RequestMapping("/")
//	@ResponseBody()
    public String Wel(Model m) {
		
		return "wel";
			
		}
	//Add member...
	@RequestMapping( value="/addMem")
	@ResponseBody
	public String saveAll(HttpServletRequest req) {
	
		int mid=Integer.parseInt(req.getParameter("mid"));
		String mname=req.getParameter("mname");
		String mgender=req.getParameter("mgender");
		int mage=Integer.parseInt(req.getParameter("mage"));
		long mno=Integer.parseInt(req.getParameter("mno"));
		List m=memberser.searMbyId(mid);
		if(m.isEmpty()) {
			memberser.saveMem(mid, mname, mgender, mage, mno, new Date());
			return "Added...your member..";
		}
		return "Already exist Member ID....";
	}
	//Update by Id...
    @RequestMapping("/upMem")
    @ResponseBody
    public String upMemById(HttpServletRequest req) {
    	int mid=Integer.parseInt(req.getParameter("mid"));
    	String mname=req.getParameter("mname");
    	int mno= Integer.parseInt(req.getParameter("mno"));
    	List<Member> lm=memberser.searMbyId(mid);
    	if(lm.isEmpty()) {
    		return "Member Not Found add new Member";
    	}
    	else {
    	 memberser.upMemById(mid, mname, mno);
    	return "Updated..."+mname;
    	}
    }
	//Searching member by Id...
    @RequestMapping("/SearMbyId")
	public String SearMbyId(Member member, HttpServletRequest req ,Model m) {
    	int id=Integer.parseInt(req.getParameter("mid"));
    	List<Member> lm=memberser.searMbyId(id);
    	m.addAttribute("lm",lm);
        m.addAllAttributes(lm);
        if(lm.isEmpty()){
        	return "notFound";
        }
        else
		 return "listMem";		 
	}
    
	

	 
	
	@RequestMapping("/member")
	public String getAllMem(Model m) {
	
		List<Member>lm= memberser.getAllMem();
		m.addAttribute("lm",lm);
		m.addAllAttributes(lm);
		if(lm.isEmpty()) {
			return "notFound";
		}
		return "listMem";
	}
	
	
	//delete Member by id
	@RequestMapping("/delMemById")
	@ResponseBody
	public String delMemById(HttpServletRequest req) {
        int mid=Integer.parseInt(req.getParameter("mid"));	
	    List m=memberser.searMbyId(mid);
	    if(m.isEmpty()) {
	      return "Member not exit...";
	    }
	    else {
	     memberser.delMemById(mid);
		return "Deleted "+mid+" Member.............";
	    }
	}
	

	//--Wel mapping achor tags--------------------------------------------------//
	@RequestMapping("/SearMby")
	public String SearMby() {
		
		return "SearMbyId";
	}
	@RequestMapping("/addMe")
	public String addMe() {
		
		return "addMem";
	}
	@RequestMapping("/upMe")
	public String upMe() {
		
		return "upMem";
	}
	@RequestMapping("/delMem")
	public String delMem() {
		
		return "delMemById";
	}
	
	
	//----------------------------------------------------//
	
	
	/*
	 * @RequestMapping("/aamember")
	 * 
	 * @ResponseBody public List<Member> getAllMems() {
	 * 
	 * List<Member>lm= memberser.getAllMem(); return lm; }
	 */
	
	
//	@RequestMapping("/addMem")
//	public String saveAll(){
//		
//		memberser.saveMem(123, "def", "dffdfd", 21, 3456433,new Date());		
//		
//		return "ADD...........";
//	}
	
	/*
	 * @RequestMapping("/amember")
	 * 
	 * @ResponseBody public List<Member> getAllMem() {
	 * 
	 * List<Member>lm= memberser.getAllMem(); return lm; }
	 */

}
