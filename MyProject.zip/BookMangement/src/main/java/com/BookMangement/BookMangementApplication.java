package com.BookMangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMangementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMangementApplication.class, args);
	}

}
