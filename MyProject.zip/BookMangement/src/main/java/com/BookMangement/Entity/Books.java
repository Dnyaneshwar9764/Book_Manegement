package com.BookMangement.Entity;

import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Books {
	
	@Id
	private int bookid;
	private int iabn;
	private String title;
	private String author;
	private String publisher;
	private Date publisher_year;
	private String genre;
	private String desciption;
	private int pages;
	private int price;
	private String language;

	
	public Books() {
		super();
	}
	
	
	public Books(int bookid, int iabn, String title, String author, String publisher, Date publisher_year, String genre,
			String desciption, int pages, int price, String language) {
		super();
		this.bookid = bookid;
		this.iabn = iabn;
		this.title = title;
		this.author = author;
		this.publisher = publisher;
		this.publisher_year = publisher_year;
		this.genre = genre;
		this.desciption = desciption;
		this.pages = pages;
		this.price = price;
		this.language = language;
	}


	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public int getIabn() {
		return iabn;
	}
	public void setIabn(int iabn) {
		this.iabn = iabn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public Date getPublisher_year() {
		return publisher_year;
	}
	public void setPublisher_year(Date publisher_year) {
		this.publisher_year = publisher_year;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getDesciption() {
		return desciption;
	}
	public void setDesciption(String desciption) {
		this.desciption = desciption;
	}
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	@Override
	public String toString() {
		return "Books [bookid=" + bookid + ", iabn=" + iabn + ", title=" + title + ", author=" + author + ", publisher="
				+ publisher + ", publisher_year=" + publisher_year + ", genre=" + genre + ", desciption=" + desciption
				+ ", pages=" + pages + ", price=" + price + ", language=" + language + "]";
	}
	
	

}
