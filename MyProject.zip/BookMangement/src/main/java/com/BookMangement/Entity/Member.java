package com.BookMangement.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Member {
	
	@Id
	private int memberID;
	private String name;
	private String gender;
	private int age;
	private long mobile;
	private Date join_year;
	
	public Member() {
		super();
	}
	

	public Member(int memberID, String name, String gender, int age, long mobile, Date join_year) {
		super();
		this.memberID = memberID;
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.mobile = mobile;
		this.join_year = join_year;
	}


	public int getMemberID() {
		return memberID;
	}

	public void setMemberID(int memberID) {
		this.memberID = memberID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public Date getJoin_year() {
		return join_year;
	}

	public void setJoin_year(Date join_year) {
		this.join_year = join_year;
	}

	@Override
	public String toString() {
		return "member [memberID=" + memberID + ", name=" + name + ", gender=" + gender + ", age=" + age + ", mobile="
				+ mobile + ", join_year=" + join_year + "]";
	}
	
	

}
