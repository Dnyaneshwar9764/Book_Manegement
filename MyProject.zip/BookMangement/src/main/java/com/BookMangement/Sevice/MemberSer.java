package com.BookMangement.Sevice;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookMangement.Entity.Member;
import com.BookMangement.Repository.MemberRepo;

@Service
public class MemberSer {
	
	@Autowired
	private MemberRepo memberRepo;
	

   //Fetching all Member in json 	
	public List<Member> getAllMem() {
		
     	return memberRepo.findAll().stream().toList();
	}
//	public void saveMem(Member m) {
//		
//		List<Member> lm=new ArrayList();
//		
//		lm.add(m);
//	
//	     memberRepo.saveAll(lm);
//	}
   //Save new Member ...
	public void saveMem(int i, String string, String string2,
			int j, long k, Date date) {
		List<Member> lm=new ArrayList<Member>();
		
		lm.add(
				new Member(i,string,string2,j,k,date)
				);
	
	     memberRepo.saveAll(lm);
	}
	
  //Delete the all member
	public int delAllMem() {
		
		 memberRepo.deleteAll();
		 return 0;
		
	}

//Search Member By Id
	public List<Member> searMbyId(int mid){
		
		return memberRepo.findById(mid).stream().toList();
		
	}
//Update Member by Id 
	public String upMemById(int mid,String mname,long mno ) {
		
		memberRepo.upMemById(mid, mname, mno);
		return mname;
	}
//Delete Member By Id
	public int delMemById(int mid) {
		memberRepo.deleteById(mid);
		return mid;
	}

	




	
}
