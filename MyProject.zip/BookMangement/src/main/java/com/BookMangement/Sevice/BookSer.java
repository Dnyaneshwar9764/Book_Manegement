package com.BookMangement.Sevice;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookMangement.Entity.Books;
import com.BookMangement.Entity.Member;
import com.BookMangement.Repository.BookRepo;

@Service
public class BookSer {
    @Autowired
	private BookRepo bookrepo;
	
	public void addBook(int bookid, int iabn, String title,
			 String author,String publisher,Date publisher_year, String genre,
			 String desciption,int pages, int price, String language) {
		
		List<Books> lb=new ArrayList<Books>();
		lb.add(
				new Books(bookid,iabn,title,author,publisher,publisher_year, genre,
						  desciption, pages,price,language));
			
		
		bookrepo.saveAll(lb);
		 
	}

	public int upBookById(int bookid, int price) {
		
		bookrepo.upBookById(bookid,price);
		return bookid;
	}

	public List<Books> searchBookById(int bookid) {
		
		return bookrepo.findById(bookid).stream().toList();
		
	}

	public List<Books> getAllBook() {
		// TODO Auto-generated method stub
		
		return bookrepo.findAll().stream().toList();
	}

	public void delByID(int bookid) {
		// TODO Auto-generated method stub
		bookrepo.deleteById(bookid);
		
	}
	
	
//	public Books bookAllSer() {
//		
//		return bookAllRepo();
//	}

}
