package com.BookMangement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.BookMangement.Entity.Books;

@Repository
public interface BookRepo extends JpaRepository<Books, Integer> {

	@Transactional
	@Modifying
	@Query("UPDATE Books SET price=:price where bookid=:bookid")
	Integer upBookById(int bookid, int price);
  
	

}
