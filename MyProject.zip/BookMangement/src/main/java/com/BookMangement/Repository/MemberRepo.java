package com.BookMangement.Repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.BookMangement.Entity.Member;


@Repository
public interface MemberRepo extends JpaRepository<Member, Integer> {

	@Transactional
	@Modifying
	@Query("UPDATE Member SET name=:mname,mobile=:mno where memberID=:mid")
	Integer upMemById(int mid,String mname,long mno);
	
	
	
}
